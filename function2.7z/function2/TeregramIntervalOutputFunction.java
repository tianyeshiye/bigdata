package function2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import scala.Tuple2;

public class TeregramIntervalOutputFunction {

	private final int timeInterval;

	public TeregramIntervalOutputFunction (int timeInterval) {
		this.timeInterval = timeInterval;
	}
	public  Iterator<Tuple2<TelegramHash, Map<Long,List<CanUnitBean>>>> call(
			final Iterator<Tuple2<TelegramHash, CanUnitBean>> tuples) throws Exception {

        return new Iterator<Tuple2<TelegramHash, Map<Long,List<CanUnitBean>>>>() {

        	private TelegramHash progress = null;
        	private List<CanUnitBean> message = null;
        	private Tuple2<TelegramHash, CanUnitBean> aheadTuple = null;
        	private Map<Long,List<CanUnitBean>> messageMap = null;

        	//
        	private void ensureNexrElement() {

        		if (progress !=null || message != null) {
        			return;
        		}

        		this.message = new ArrayList<>();
        		this.messageMap = new HashMap<>();

        		if (aheadTuple != null) {
        			this.progress = aheadTuple._1;
        			this.message.add(aheadTuple._2);
        			this.aheadTuple = null;
        		}

        		while (tuples.hasNext()) {
        			final Tuple2<TelegramHash, CanUnitBean> tuple = tuples.next();
        			long tmStampThis = (long)(tuple._2.getCanTime() % timeInterval);
        			tmStampThis = tuple._2.getCanTime() - tmStampThis;

        			if (progress == null || progress.equals(tuple._1)) {

        				List<CanUnitBean> reCanUnitBean = messageMap.get(tmStampThis);
        				if (reCanUnitBean == null) {
        					reCanUnitBean = new ArrayList<>();
        					reCanUnitBean.add(tuple._2);
        					this.messageMap.put(tmStampThis, reCanUnitBean);
        				} else {

        				}
        				this.progress = tuple._1;
        				this.message.add(tuple._2);
        			} else {
        				this.aheadTuple = tuple;
        				break;
        			}
        		}
        	}
        	@Override
        	public boolean hasNext() {
        		ensureNexrElement();
        		return message != null && !message.isEmpty();
        	}
        	@Override
        	public Tuple2<TelegramHash,  Map<Long,List<CanUnitBean>>> next() {
        		if (!hasNext()) {
        			//throw new Exception();
        		}
        		Tuple2<TelegramHash, Map<Long,List<CanUnitBean>>> next =
        				new Tuple2<TelegramHash,Map<Long,List<CanUnitBean>>>(progress, messageMap);
    			this.progress = null;
    			this.message= null;
        		return next;
        	}
        };
	}
}

//1111:1506787111000-----------
//34:1506787111020:{c022_dummy16=2, c022_dummy15=1, c022_dummy18=4, c022_dummy17=3}
//513:1506787111150:{c201_dummy20=66, c201_dummy19=55, c201_dummy18=44, c201_dummy15=11, c201_dummy17=33, c201_dummy16=22}
//513:1506787111050:{c201_dummy20=6, c201_dummy19=5, c201_dummy18=4, c201_dummy15=1, c201_dummy17=3, c201_dummy16=2}
//290:1506787111130:{c122_dummy15=11, c122_dummy16=22, c122_dummy17=33, c122_dummy18=44, c122_dummy19=55}
//290:1506787111030:{c122_dummy15=1, c122_dummy16=2, c122_dummy17=3, c122_dummy18=4, c122_dummy19=5}
//1:1506787111110:{c001_dummy16=22, c001_dummy17=33, c001_dummy15=11}
//34:1506787111120:{c022_dummy16=22, c022_dummy15=11, c022_dummy18=44, c022_dummy17=33}
//1:1506787111010:{c001_dummy16=2, c001_dummy17=3, c001_dummy15=1}
//2222:1506787222000-----------
//513:1506787222040:{c201_dummy20=6, c201_dummy19=5, c201_dummy18=4, c201_dummy15=1, c201_dummy17=3, c201_dummy16=2}
//34:1506787222120:{c022_dummy16=22, c022_dummy15=11, c022_dummy18=44, c022_dummy17=33}
//290:1506787222030:{c122_dummy15=1, c122_dummy16=2, c122_dummy17=3, c122_dummy18=4, c122_dummy19=5}
//1:1506787222110:{c001_dummy16=22, c001_dummy17=33, c001_dummy15=11}
//513:1506787222140:{c201_dummy20=66, c201_dummy19=55, c201_dummy18=44, c201_dummy15=11, c201_dummy17=33, c201_dummy16=22}
//34:1506787222220:{c022_dummy16=null, c022_dummy15=1, c022_dummy18=4, c022_dummy17=null}
//290:1506787222130:{c122_dummy15=11, c122_dummy16=22, c122_dummy17=33, c122_dummy18=44, c122_dummy19=55}
//1:1506787222210:{c001_dummy16=null, c001_dummy17=3, c001_dummy15=1}
//513:1506787222240:{c201_dummy20=null, c201_dummy19=null, c201_dummy18=null, c201_dummy15=1, c201_dummy17=null, c201_dummy16=2}
//290:1506787222230:{c122_dummy15=1, c122_dummy16=null, c122_dummy17=null, c122_dummy18=null, c122_dummy19=5}
//34:1506787222020:{c022_dummy16=2, c022_dummy15=1, c022_dummy18=4, c022_dummy17=3}
