package function2;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import scala.Tuple2;

public class TeregramOutputFunction {
	private static final long serialVersionUID = - 2022345678L;
	private final int timeInterval;

	public TeregramOutputFunction (int timeInterval) {
		this.timeInterval = timeInterval;
	}
	public  Iterator<Tuple2<TelegramHash, List<CanUnitBean>>> call(
			final Iterator<Tuple2<TelegramHash, CanUnitBean>> tuples) throws Exception {
        return new Iterator<Tuple2<TelegramHash, List<CanUnitBean>>>() {

        	private TelegramHash progress = null;
        	private List<CanUnitBean> message = null;
        	private Tuple2<TelegramHash, CanUnitBean> aheadTuple = null;

        	//
        	private void ensureNexrElement() {

        		if (progress !=null || message != null) {
        			return;
        		}

        		this.message = new ArrayList<>();

        		if (aheadTuple != null) {
        			this.progress = aheadTuple._1;
        			this.message.add(aheadTuple._2);
        			this.aheadTuple = null;
        		}

        		while (tuples.hasNext()) {
        			final Tuple2<TelegramHash, CanUnitBean> tuple = tuples.next();
        			if (progress == null || progress.equals(tuple._1)) {
        				this.progress = tuple._1;
        				this.message.add(tuple._2);
        			} else {
        				this.aheadTuple = tuple;
        				break;
        			}
        		}
        	}
        	@Override
        	public boolean hasNext() {
        		ensureNexrElement();
        		return message != null && !message.isEmpty();
        	}
        	@Override
        	public Tuple2<TelegramHash, List<CanUnitBean>> next() {
        		if (!hasNext()) {
        			//throw new Exception();
        		}
        		Tuple2<TelegramHash, List<CanUnitBean>> next = new Tuple2<TelegramHash, List<CanUnitBean>>(progress,message);
    			this.progress = null;
    			this.message= null;
        		return next;
        	}
        };
	}
}


//1111:1506787111000-----------
//1:1506787111010:{c001_dummy16=2, c001_dummy17=3, c001_dummy15=1}
//34:1506787111020:{c022_dummy16=2, c022_dummy15=1, c022_dummy18=4, c022_dummy17=3}
//290:1506787111030:{c122_dummy15=1, c122_dummy16=2, c122_dummy17=3, c122_dummy18=4, c122_dummy19=5}
//513:1506787111050:{c201_dummy20=6, c201_dummy19=5, c201_dummy18=4, c201_dummy15=1, c201_dummy17=3, c201_dummy16=2}
//1:1506787111110:{c001_dummy16=22, c001_dummy17=33, c001_dummy15=11}
//34:1506787111120:{c022_dummy16=22, c022_dummy15=11, c022_dummy18=44, c022_dummy17=33}
//290:1506787111130:{c122_dummy15=11, c122_dummy16=22, c122_dummy17=33, c122_dummy18=44, c122_dummy19=55}
//513:1506787111150:{c201_dummy20=66, c201_dummy19=55, c201_dummy18=44, c201_dummy15=11, c201_dummy17=33, c201_dummy16=22}
//1:1506787111110:{c001_dummy16=null, c001_dummy17=3, c001_dummy15=1}
//34:1506787111120:{c022_dummy16=null, c022_dummy15=1, c022_dummy18=4, c022_dummy17=null}
//290:1506787111130:{c122_dummy15=1, c122_dummy16=null, c122_dummy17=null, c122_dummy18=null, c122_dummy19=5}
//513:1506787111150:{c201_dummy20=null, c201_dummy19=null, c201_dummy18=null, c201_dummy15=1, c201_dummy17=null, c201_dummy16=2}
//2222:1506787222000-----------
//1:1506787222010:{c001_dummy16=2, c001_dummy17=3, c001_dummy15=1}
//34:1506787222020:{c022_dummy16=2, c022_dummy15=1, c022_dummy18=4, c022_dummy17=3}
//290:1506787222030:{c122_dummy15=1, c122_dummy16=2, c122_dummy17=3, c122_dummy18=4, c122_dummy19=5}
//513:1506787222040:{c201_dummy20=6, c201_dummy19=5, c201_dummy18=4, c201_dummy15=1, c201_dummy17=3, c201_dummy16=2}
//1:1506787222110:{c001_dummy16=22, c001_dummy17=33, c001_dummy15=11}
//34:1506787222120:{c022_dummy16=22, c022_dummy15=11, c022_dummy18=44, c022_dummy17=33}
//290:1506787222130:{c122_dummy15=11, c122_dummy16=22, c122_dummy17=33, c122_dummy18=44, c122_dummy19=55}
//513:1506787222140:{c201_dummy20=66, c201_dummy19=55, c201_dummy18=44, c201_dummy15=11, c201_dummy17=33, c201_dummy16=22}
//1:1506787222210:{c001_dummy16=null, c001_dummy17=3, c001_dummy15=1}
//34:1506787222220:{c022_dummy16=null, c022_dummy15=1, c022_dummy18=4, c022_dummy17=null}
//290:1506787222230:{c122_dummy15=1, c122_dummy16=null, c122_dummy17=null, c122_dummy18=null, c122_dummy19=5}
//513:1506787222240:{c201_dummy20=null, c201_dummy19=null, c201_dummy18=null, c201_dummy15=1, c201_dummy17=null, c201_dummy16=2}