package function2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import scala.Tuple2;

public class TeregramOutputFunctionTY {
	private static final long serialVersionUID = -2022345678L;
	private final int timeInterval;

	public TeregramOutputFunctionTY(int timeInterval) {
		this.timeInterval = timeInterval;
	}
	public Iterator<Tuple2<TelegramHash, Map<Long, List<CanUnitBean>>>> call(
			final Iterator<Tuple2<TelegramHash, CanUnitBean>> tuples)
			throws Exception {
		return new Iterator<Tuple2<TelegramHash, Map<Long, List<CanUnitBean>>>>() {

			private TelegramHash progress = null;

			private LinkedHashMap<Long, List<CanUnitBean>> canUnitBeanHashMap;

			private Tuple2<TelegramHash, CanUnitBean> aheadTuple = null;

			private void ensureNexrElement() {

				if (progress != null || canUnitBeanHashMap != null) {
					return;
				}

				this.canUnitBeanHashMap = new LinkedHashMap<Long, List<CanUnitBean>>();

				if (aheadTuple != null) {

					this.progress = aheadTuple._1;
					addTocanUnitBeanHashMap(canUnitBeanHashMap, aheadTuple);
					this.aheadTuple = null;
				}

				while (tuples.hasNext()) {

					final Tuple2<TelegramHash, CanUnitBean> tuple = tuples
							.next();

					if (progress == null || progress.equals(tuple._1)) {

						this.progress = tuple._1;

						addTocanUnitBeanHashMap(canUnitBeanHashMap, tuple);

					} else {

						this.aheadTuple = tuple;
						break;
					}
				}
			}
			@Override
			public boolean hasNext() {
				ensureNexrElement();
				return canUnitBeanHashMap != null
						&& !canUnitBeanHashMap.isEmpty();
			}
			@Override
			public Tuple2<TelegramHash, Map<Long, List<CanUnitBean>>> next() {

				if (!hasNext()) {
					// throw new Exception();
				}
				Tuple2<TelegramHash, Map<Long, List<CanUnitBean>>> next = new Tuple2<TelegramHash, Map<Long, List<CanUnitBean>>>(
						progress, canUnitBeanHashMap);
				this.progress = null;
				this.canUnitBeanHashMap = null;
				return next;
			}

			private void addTocanUnitBeanHashMap(
					Map<Long, List<CanUnitBean>> canUnitBeanHashMap,
					Tuple2<TelegramHash, CanUnitBean> tuple) {

				long longKey = tuple._2.getCanTime();

				if (canUnitBeanHashMap.containsKey(longKey)) {

					canUnitBeanHashMap.get(longKey).add(tuple._2);
				} else {

					List<CanUnitBean> canUnitBeanlist = new ArrayList<CanUnitBean>();
					canUnitBeanlist.add(tuple._2);
					canUnitBeanHashMap.put(longKey, canUnitBeanlist);
				}

			}
		};
	}
}

// 1111:1506787111000-----------
// 1:1506787111010:{c001_dummy16=2, c001_dummy17=3, c001_dummy15=1}
// 34:1506787111020:{c022_dummy16=2, c022_dummy15=1, c022_dummy18=4,
// c022_dummy17=3}
// 290:1506787111030:{c122_dummy15=1, c122_dummy16=2, c122_dummy17=3,
// c122_dummy18=4, c122_dummy19=5}
// 513:1506787111050:{c201_dummy20=6, c201_dummy19=5, c201_dummy18=4,
// c201_dummy15=1, c201_dummy17=3, c201_dummy16=2}
// 1:1506787111110:{c001_dummy16=22, c001_dummy17=33, c001_dummy15=11}
// 34:1506787111120:{c022_dummy16=22, c022_dummy15=11, c022_dummy18=44,
// c022_dummy17=33}
// 290:1506787111130:{c122_dummy15=11, c122_dummy16=22, c122_dummy17=33,
// c122_dummy18=44, c122_dummy19=55}
// 513:1506787111150:{c201_dummy20=66, c201_dummy19=55, c201_dummy18=44,
// c201_dummy15=11, c201_dummy17=33, c201_dummy16=22}
// 1:1506787111110:{c001_dummy16=null, c001_dummy17=3, c001_dummy15=1}
// 34:1506787111120:{c022_dummy16=null, c022_dummy15=1, c022_dummy18=4,
// c022_dummy17=null}
// 290:1506787111130:{c122_dummy15=1, c122_dummy16=null, c122_dummy17=null,
// c122_dummy18=null, c122_dummy19=5}
// 513:1506787111150:{c201_dummy20=null, c201_dummy19=null, c201_dummy18=null,
// c201_dummy15=1, c201_dummy17=null, c201_dummy16=2}
// 2222:1506787222000-----------
// 1:1506787222010:{c001_dummy16=2, c001_dummy17=3, c001_dummy15=1}
// 34:1506787222020:{c022_dummy16=2, c022_dummy15=1, c022_dummy18=4,
// c022_dummy17=3}
// 290:1506787222030:{c122_dummy15=1, c122_dummy16=2, c122_dummy17=3,
// c122_dummy18=4, c122_dummy19=5}
// 513:1506787222040:{c201_dummy20=6, c201_dummy19=5, c201_dummy18=4,
// c201_dummy15=1, c201_dummy17=3, c201_dummy16=2}
// 1:1506787222110:{c001_dummy16=22, c001_dummy17=33, c001_dummy15=11}
// 34:1506787222120:{c022_dummy16=22, c022_dummy15=11, c022_dummy18=44,
// c022_dummy17=33}
// 290:1506787222130:{c122_dummy15=11, c122_dummy16=22, c122_dummy17=33,
// c122_dummy18=44, c122_dummy19=55}
// 513:1506787222140:{c201_dummy20=66, c201_dummy19=55, c201_dummy18=44,
// c201_dummy15=11, c201_dummy17=33, c201_dummy16=22}
// 1:1506787222210:{c001_dummy16=null, c001_dummy17=3, c001_dummy15=1}
// 34:1506787222220:{c022_dummy16=null, c022_dummy15=1, c022_dummy18=4,
// c022_dummy17=null}
// 290:1506787222230:{c122_dummy15=1, c122_dummy16=null, c122_dummy17=null,
// c122_dummy18=null, c122_dummy19=5}
// 513:1506787222240:{c201_dummy20=null, c201_dummy19=null, c201_dummy18=null,
// c201_dummy15=1, c201_dummy17=null, c201_dummy16=2}