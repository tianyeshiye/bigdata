package function2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.PairFlatMapFunction;
import org.apache.spark.api.java.function.VoidFunction;

import jodd.util.StringUtil;
import scala.Tuple2;

public class SortWithinTeregramWithinPartitionsWithGpsDriver {

    public static void main(String[] args) throws Exception {

        SparkConf conf = new SparkConf().setAppName("CanTimeReducer").setMaster("local[2]");
        JavaSparkContext sc = new JavaSparkContext(conf);

        // 1506787111000 0x01 0x22 0x122 0x201
        TelegramHash telegramHash1 = new TelegramHash("1111", 1506787111000L);

        CanUnitBean canUnitBean1_00_1000 = Unit.createCanUnitBean((short) 0x00, "1506787111000");

        CanUnitBean canUnitBean1_01_1000 = Unit.createCanUnitBean((short) 0x01, "1506787111000");
        CanUnitBean canUnitBean1_22_1000 = Unit.createCanUnitBean((short) 0x22, "1506787111000");
        CanUnitBean canUnitBean1_122_1000 = Unit.createCanUnitBean((short) 0x122, "1506787111000");
        CanUnitBean canUnitBean1_201_1000 = Unit.createCanUnitBean((short) 0x201, "1506787111000");

        CanUnitBean canUnitBean1_01_1010 = Unit.createCanUnitBeanNull((short) 0x01, "1506787111010");
        CanUnitBean canUnitBean1_22_1010 = Unit.createCanUnitBeanNull((short) 0x22, "1506787111010");
        CanUnitBean canUnitBean1_122_1010 = Unit.createCanUnitBeanNull((short) 0x122, "1506787111010");
        CanUnitBean canUnitBean1_201_1010 = Unit.createCanUnitBeanNull((short) 0x201, "1506787111010");

        CanUnitBean canUnitBean1_01_1020 = Unit.createCanUnitBean2((short) 0x01, "1506787111020");
        CanUnitBean canUnitBean1_22_1020 = Unit.createCanUnitBean2((short) 0x22, "1506787111020");
        CanUnitBean canUnitBean1_122_1020 = Unit.createCanUnitBean2((short) 0x122, "1506787111020");
        CanUnitBean canUnitBean1_201_1020 = Unit.createCanUnitBean2((short) 0x201, "1506787111020");

        CanUnitBean canUnitBean1_01_1030 = Unit.createCanUnitBean2((short) 0x01, "1506787111030");
        CanUnitBean canUnitBean1_22_1030 = Unit.createCanUnitBean2((short) 0x22, "1506787111030");
        CanUnitBean canUnitBean1_122_1030 = Unit.createCanUnitBean2((short) 0x122, "1506787111030");
        CanUnitBean canUnitBean1_201_1030 = Unit.createCanUnitBean2((short) 0x201, "1506787111030");

        CanUnitBean canUnitBean1_00_2000 = Unit.createCanUnitBean((short) 0x00, "1506787112000");

        CanUnitBean canUnitBean1_01_2000 = Unit.createCanUnitBean((short) 0x01, "1506787112000");
        CanUnitBean canUnitBean1_22_2000 = Unit.createCanUnitBean((short) 0x22, "1506787112000");
        CanUnitBean canUnitBean1_122_2000 = Unit.createCanUnitBean((short) 0x122, "1506787112000");
        CanUnitBean canUnitBean1_201_2000 = Unit.createCanUnitBean((short) 0x201, "1506787112000");

        CanUnitBean canUnitBean1_01_2010 = Unit.createCanUnitBeanNull((short) 0x01, "1506787112010");
        CanUnitBean canUnitBean1_22_2010 = Unit.createCanUnitBeanNull((short) 0x22, "1506787112010");
        CanUnitBean canUnitBean1_122_2010 = Unit.createCanUnitBeanNull((short) 0x122, "1506787112010");
        CanUnitBean canUnitBean1_201_2010 = Unit.createCanUnitBeanNull((short) 0x201, "1506787112010");

        CanUnitBean canUnitBean1_00_3000 = Unit.createCanUnitBean((short) 0x00, "1506787113000");

        CanUnitBean canUnitBean1_01_3010 = Unit.createCanUnitBean((short) 0x01, "1506787113010");
        CanUnitBean canUnitBean1_22_3020 = Unit.createCanUnitBean((short) 0x22, "1506787113020");
        CanUnitBean canUnitBean1_122_3030 = Unit.createCanUnitBean((short) 0x122, "1506787113030");
        CanUnitBean canUnitBean1_201_3040 = Unit.createCanUnitBean((short) 0x201, "1506787113040");

        CanUnitBean canUnitBean1_01_3010_null = Unit.createCanUnitBeanNull((short) 0x01, "1506787113010");
        CanUnitBean canUnitBean1_22_3020_null = Unit.createCanUnitBeanNull((short) 0x22, "1506787113020");
        CanUnitBean canUnitBean1_122_3030_null = Unit.createCanUnitBeanNull((short) 0x122, "1506787113030");
        CanUnitBean canUnitBean1_201_3040_null = Unit.createCanUnitBeanNull((short) 0x201, "1506787113040");

        // 1506787222000 0x01 0x22 0x122 0x201
        TelegramHash telegramHash2 = new TelegramHash("2222", 1506787222000L);

        CanUnitBean canUnitBean2_00_2000 = Unit.createCanUnitBean((short) 0x00, "1506787222010");

        CanUnitBean canUnitBean2_01_2000 = Unit.createCanUnitBean((short) 0x01, "1506787222010");
        CanUnitBean canUnitBean2_22_2000 = Unit.createCanUnitBean((short) 0x22, "1506787222010");
        CanUnitBean canUnitBean2_122_2000 = Unit.createCanUnitBean((short) 0x122, "1506787222010");
        CanUnitBean canUnitBean2_201_2000 = Unit.createCanUnitBean((short) 0x201, "1506787222010");

        CanUnitBean canUnitBean2_00_3000 = Unit.createCanUnitBean((short) 0x00, "1506787223010");

        CanUnitBean canUnitBean2_01_3000 = Unit.createCanUnitBean((short) 0x01, "1506787223010");
        CanUnitBean canUnitBean2_22_3000 = Unit.createCanUnitBean((short) 0x22, "1506787223010");
        CanUnitBean canUnitBean2_122_3000 = Unit.createCanUnitBean((short) 0x122, "1506787223010");
        CanUnitBean canUnitBean2_201_3000 = Unit.createCanUnitBean((short) 0x201, "1506787223010");

        CanUnitBean canUnitBean2_00_4000 = Unit.createCanUnitBean((short) 0x00, "1506787224010");

        CanUnitBean canUnitBean2_01_4010 = Unit.createCanUnitBean((short) 0x01, "1506787224010");
        CanUnitBean canUnitBean2_22_4020 = Unit.createCanUnitBean((short) 0x22, "1506787224020");
        CanUnitBean canUnitBean2_122_4030 = Unit.createCanUnitBean((short) 0x122, "1506787224030");
        CanUnitBean canUnitBean2_201_4040 = Unit.createCanUnitBean((short) 0x201, "1506787224040");

        JavaRDD<Tuple2<TelegramHash, CanUnitBean>> rdd = sc.parallelize(Arrays.asList(

                // 1506787111000
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_00_1000),

                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_01_1000),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_22_1000),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_122_1000),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_201_1000),

                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_01_1010),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_22_1010),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_122_1010),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_201_1010),

                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_01_1020),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_22_1020),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_122_1020),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_201_1020),

                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_01_1030),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_22_1030),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_122_1030),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_201_1030),

                // 1506787113000 1506787113000 1506787113000
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_00_3000),

                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_01_3010),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_22_3020),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_122_3030),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_201_3040),

                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_01_3010_null),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_22_3020_null),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_122_3030_null),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_201_3040_null),

                // 1506787112000
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_00_2000),

                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_01_2000),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_22_2000),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_122_2000),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_201_2000),

                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_01_2010),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_22_2010),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_122_2010),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash1, canUnitBean1_201_2010),

                new Tuple2<TelegramHash, CanUnitBean>(telegramHash2, canUnitBean2_00_2000),

                new Tuple2<TelegramHash, CanUnitBean>(telegramHash2, canUnitBean2_01_2000),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash2, canUnitBean2_22_2000),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash2, canUnitBean2_122_2000),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash2, canUnitBean2_201_2000),

                new Tuple2<TelegramHash, CanUnitBean>(telegramHash2, canUnitBean2_00_3000),

                new Tuple2<TelegramHash, CanUnitBean>(telegramHash2, canUnitBean2_01_3000),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash2, canUnitBean2_22_3000),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash2, canUnitBean2_122_3000),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash2, canUnitBean2_201_3000),

                new Tuple2<TelegramHash, CanUnitBean>(telegramHash2, canUnitBean2_00_4000),

                new Tuple2<TelegramHash, CanUnitBean>(telegramHash2, canUnitBean2_01_4010),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash2, canUnitBean2_22_4020),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash2, canUnitBean2_122_4030),
                new Tuple2<TelegramHash, CanUnitBean>(telegramHash2, canUnitBean2_201_4040)), 1);

        JavaPairRDD<TelegramHash, CanUnitBean> pairRDD = JavaPairRDD.fromJavaRDD(rdd);

        System.out.println("Before function, test data ***********************");

        pairRDD.foreach(new VoidFunction<Tuple2<TelegramHash, CanUnitBean>>() {

            String deviceId = null;

            @Override
            public void call(Tuple2<TelegramHash, CanUnitBean> tp2) throws Exception {

                if (StringUtil.isEmpty(deviceId) || !tp2._1.deviceId.equals(deviceId)) {

                    deviceId = tp2._1.deviceId;
                    System.out.println(tp2._1.deviceId + ":" + tp2._1.timestamp + "-----------");
                }
                System.out.println(tp2._2.getCanId() + ":" + tp2._2.getCanTime() + ":" + tp2._2.getConvertedDataMap());
            }
        });

        System.out.println(
                "**************************** 10  10  10  10  10  10  10  10  10  10  10  10  10  10 **************************************************");
        System.out.println("******************************************************************************");
        System.out.println("↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓");
        System.out.println("After function, iterator test data *********************** timeInterval  10");
        System.out.println("*****************JavaPairRDD<TelegramHash, List<List<CanUnitBean>>>*************");

        JavaPairRDD<TelegramHash, List<List<CanUnitBean>>> pairRDDReducerBy10 = pairRDD
                .mapPartitionsToPair(new SortWithinTeregramWithinPartitionsWithGps(10));

        pairRDDReducerBy10.foreach(new VoidFunction<Tuple2<TelegramHash, List<List<CanUnitBean>>>>() {

            @Override
            public void call(Tuple2<TelegramHash, List<List<CanUnitBean>>> tp10) throws Exception {

                System.out.println(tp10._1.deviceId + ":" + tp10._1.timestamp + "-----------");

                List<List<CanUnitBean>> listList = tp10._2;

                for (List<CanUnitBean> list : listList) {

                    System.out.println("         " + list.get(0).getCanTimeInterval() + "      ");
                    for (CanUnitBean bean : list) {
                        System.out.println(bean.getCanId() + ":" + bean.getCanTime() + ":" + bean.getCanTimeInterval()
                                + ":" + bean.getConvertedDataMap());
                    }
                }
            }
        });

        System.out.println(
                "**************************** 10  10  10  10  10  10  10  10  10  10  10  10  10  10 **************************************************");
        System.out.println("******************************************************************************");
        System.out.println("↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓");
        System.out.println("After function, iterator test data *****************************************");
        System.out.println("*****************JavaPairRDD<TelegramHash, List<CanUnitBean>> *************");

        JavaPairRDD<TelegramHash, List<CanUnitBean>> pairRDDReducerBy10Single = pairRDDReducerBy10.flatMapToPair(
                new PairFlatMapFunction<Tuple2<TelegramHash, List<List<CanUnitBean>>>, TelegramHash, List<CanUnitBean>>() {

                    private static final long serialVersionUID = -5389825673734449220L;

                    @Override
                    public Iterator<Tuple2<TelegramHash, List<CanUnitBean>>> call(
                            Tuple2<TelegramHash, List<List<CanUnitBean>>> tp2) throws Exception {

                        List<Tuple2<TelegramHash, List<CanUnitBean>>> tuble2List = new ArrayList<>();

                        for (List<CanUnitBean> beanList : tp2._2) {

                            tuble2List.add(new Tuple2<TelegramHash, List<CanUnitBean>>(tp2._1, beanList));
                        }

                        return tuble2List.iterator();
                    }
                });

        pairRDDReducerBy10Single.foreach(new VoidFunction<Tuple2<TelegramHash, List<CanUnitBean>>>() {

            @Override
            public void call(Tuple2<TelegramHash, List<CanUnitBean>> tp10) throws Exception {

                System.out.println(tp10._1.deviceId + ":" + tp10._1.timestamp + "-----------");

                List<CanUnitBean> listList = tp10._2;

                long canTime = 0;
                long canTimeInterval = 0;

                for (CanUnitBean bean : listList) {

                    if (canTime != bean.getCanTime() && canTimeInterval != bean.getCanTimeInterval()) {

                        System.out.println("         " + bean.getCanTimeInterval() + "      ");
                        canTime = bean.getCanTime();
                        canTimeInterval = bean.getCanTimeInterval();
                    }

                    System.out.println(bean.getCanId() + ":" + bean.getCanTime() + ":" + bean.getCanTimeInterval() + ":"
                            + bean.getConvertedDataMap());
                }
            }
        });

        System.out.println(
                "**************************** 100  100  100  100  100  100  100  100  100 **************************************************");
        System.out.println("******************************************************************************");
        System.out.println("↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓");
        System.out.println("After function, iterator test data *********************** timeInterval  100");
        System.out.println("*****************JavaPairRDD<TelegramHash, List<List<CanUnitBean>>>*************");

        JavaPairRDD<TelegramHash, List<List<CanUnitBean>>> pairRDDReducerBy100 = pairRDD
                .mapPartitionsToPair(new SortWithinTeregramWithinPartitionsWithGps(100));

        pairRDDReducerBy100.foreach(new VoidFunction<Tuple2<TelegramHash, List<List<CanUnitBean>>>>() {

            @Override
            public void call(Tuple2<TelegramHash, List<List<CanUnitBean>>> tp100) throws Exception {

                System.out.println(tp100._1.deviceId + ":" + tp100._1.timestamp + "-----------");

                List<List<CanUnitBean>> listList = tp100._2;

                for (List<CanUnitBean> list : listList) {

                    System.out.println("         " + list.get(0).getCanTimeInterval() + "      ");
                    for (CanUnitBean bean : list) {
                        System.out.println(bean.getCanId() + ":" + bean.getCanTime() + ":" + bean.getCanTimeInterval()
                                + ":" + bean.getConvertedDataMap());
                    }
                }
            }
        });

        System.out.println(
                "**************************** 100  100  100  100  100  100  100  100  100 **************************************************");
        System.out.println("******************************************************************************");
        System.out.println("↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓");
        System.out.println("After function, iterator test data *****************************************");
        System.out.println("*****************JavaPairRDD<TelegramHash, List<CanUnitBean>> *************");

        JavaPairRDD<TelegramHash, List<CanUnitBean>> pairRDDReducerBy100Single = pairRDDReducerBy100.flatMapToPair(
                new PairFlatMapFunction<Tuple2<TelegramHash, List<List<CanUnitBean>>>, TelegramHash, List<CanUnitBean>>() {

                    private static final long serialVersionUID = -5389825673734449220L;

                    @Override
                    public Iterator<Tuple2<TelegramHash, List<CanUnitBean>>> call(
                            Tuple2<TelegramHash, List<List<CanUnitBean>>> tp2) throws Exception {

                        List<Tuple2<TelegramHash, List<CanUnitBean>>> tuble2List = new ArrayList<>();

                        for (List<CanUnitBean> beanList : tp2._2) {

                            tuble2List.add(new Tuple2<TelegramHash, List<CanUnitBean>>(tp2._1, beanList));
                        }

                        return tuble2List.iterator();
                    }
                });

        pairRDDReducerBy100Single.foreach(new VoidFunction<Tuple2<TelegramHash, List<CanUnitBean>>>() {

            @Override
            public void call(Tuple2<TelegramHash, List<CanUnitBean>> tp100) throws Exception {

                System.out.println(tp100._1.deviceId + ":" + tp100._1.timestamp + "-----------");

                List<CanUnitBean> listList = tp100._2;

                long canTime = 0;
                long canTimeInterval = 0;

                for (CanUnitBean bean : listList) {

                    if (canTime != bean.getCanTime() && canTimeInterval != bean.getCanTimeInterval()) {

                        System.out.println("         " + bean.getCanTimeInterval() + "      ");
                        canTime = bean.getCanTime();
                        canTimeInterval = bean.getCanTimeInterval();
                    }

                    System.out.println(bean.getCanId() + ":" + bean.getCanTime() + ":" + bean.getCanTimeInterval() + ":"
                            + bean.getConvertedDataMap());
                }
            }
        });

    }

}
