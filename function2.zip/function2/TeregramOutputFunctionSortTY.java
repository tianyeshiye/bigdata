package function2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.spark.api.java.function.PairFlatMapFunction;

import function2.CanUnitBean;
import function2.TelegramHash;
import scala.Tuple2;

public class TeregramOutputFunctionSortTY implements
        PairFlatMapFunction<Iterator<Tuple2<TelegramHash, CanUnitBean>>, TelegramHash, Map<Long, List<CanUnitBean>>> {

    private static final long serialVersionUID = -2022345678L;
    private final int timeInterval;

    public TeregramOutputFunctionSortTY(int timeInterval) {
        this.timeInterval = timeInterval;
    }

    public Iterator<Tuple2<TelegramHash, Map<Long, List<CanUnitBean>>>> call(
            final Iterator<Tuple2<TelegramHash, CanUnitBean>> tuples) throws Exception {

        return new Iterator<Tuple2<TelegramHash, Map<Long, List<CanUnitBean>>>>() {

            private TelegramHash progress = null;

            private Tuple2<TelegramHash, CanUnitBean> aheadTuple = null;

            private LinkedHashMap<Long, List<CanUnitBean>> canUnitBeanHashMap;

            private Map<Long, Map<Short, Integer>> canIdOrderMap;

            private void ensureNexrElement() {

                if (progress != null || canUnitBeanHashMap != null) {
                    return;
                }

                this.canUnitBeanHashMap = new LinkedHashMap<Long, List<CanUnitBean>>();

                this.canIdOrderMap = new HashMap<Long, Map<Short, Integer>>();

                if (aheadTuple != null) {

                    this.progress = aheadTuple._1;
                    addTocanUnitBeanHashMap(canUnitBeanHashMap, aheadTuple);
                    this.aheadTuple = null;
                }

                while (tuples.hasNext()) {

                    final Tuple2<TelegramHash, CanUnitBean> tuple = tuples.next();

                    if (progress == null || progress.equals(tuple._1)) {

                        this.progress = tuple._1;

                        addTocanUnitBeanHashMap(canUnitBeanHashMap, tuple);

                    } else {

                        this.aheadTuple = tuple;
                        break;
                    }
                }
            }

            @Override
            public boolean hasNext() {
                ensureNexrElement();
                return canUnitBeanHashMap != null && !canUnitBeanHashMap.isEmpty();
            }

            @Override
            public Tuple2<TelegramHash, Map<Long, List<CanUnitBean>>> next() {

                if (!hasNext()) {
                    return null;
                }
                Tuple2<TelegramHash, Map<Long, List<CanUnitBean>>> next = new Tuple2<TelegramHash, Map<Long, List<CanUnitBean>>>(
                        progress, canUnitBeanHashMap);
                this.progress = null;
                this.canUnitBeanHashMap = null;
                this.canIdOrderMap = null;
                return next;
            }

            private void addTocanUnitBeanHashMap(Map<Long, List<CanUnitBean>> canUnitBeanHashMap,
                    Tuple2<TelegramHash, CanUnitBean> tuple) {

                long longKey = getCanTimeIntervalKey(tuple._2, timeInterval);

                CanUnitBean newCanUnitBean = tuple._2;

                // ******** important
                newCanUnitBean.setCanTimeInterval(longKey);
                // ******** important

                if (canUnitBeanHashMap.containsKey(longKey)) {

                    List<CanUnitBean> canUnitBeanList = canUnitBeanHashMap.get(longKey);

                    Map<Short, Integer> canIdOrder = canIdOrderMap.get(longKey);

                    if (canIdOrder.containsKey(newCanUnitBean.getCanId())) {

                        Integer index = canIdOrder.get(newCanUnitBean.getCanId());

                        CanUnitBean originalCanUnitBean = canUnitBeanList.get(index);

                        replaceCanUnitBeanContent(originalCanUnitBean, newCanUnitBean);

                    } else {

                        canUnitBeanList.add(newCanUnitBean);

                        canIdOrder.put(newCanUnitBean.getCanId(), canIdOrder.size());
                    }

                } else {

                    List<CanUnitBean> canUnitBeanlist = new ArrayList<CanUnitBean>();

                    canUnitBeanlist.add(newCanUnitBean);

                    canUnitBeanHashMap.put(longKey, canUnitBeanlist);

                    Map<Short, Integer> a = new HashMap<Short, Integer>();
                    a.put(newCanUnitBean.getCanId(), 0);
                    canIdOrderMap.put(longKey, a);
                }
            }
        };
    }

    // Calculation key by Interval
    private Long getCanTimeIntervalKey(CanUnitBean canUnitBean, int timeInterval) {

        long canTime = canUnitBean.getCanTime();

        long canTime1 = canTime / timeInterval;

        long canTime2 = canTime1 * timeInterval;

        return canTime2;
    }

    // replace canUnitBean content
    private void replaceCanUnitBeanContent(CanUnitBean targetCanUnitBean, CanUnitBean sourceCanUnitBean) {

        Map<String, Object> targetCanUnitBeanDataMap = (Map<String, Object>) targetCanUnitBean.getConvertedDataMap();

        Map<String, Object> sourceCanUnitBeanDataMap = (Map<String, Object>) sourceCanUnitBean.getConvertedDataMap();

        targetCanUnitBeanDataMap.forEach((key, value) -> {

            if (sourceCanUnitBeanDataMap.get(key) != null) {

                targetCanUnitBeanDataMap.replace(key, sourceCanUnitBeanDataMap.get(key));
            }
        });
    }

    private void sortCanUnitBeanByCanTime(List<CanUnitBean> canUnitBeans) {

        Collections.sort(canUnitBeans, new Comparator<CanUnitBean>() {

            public int compare(CanUnitBean arg0, CanUnitBean arg1) {

                if (arg0.getCanTime() >= arg1.getCanTime()) {

                    return 1;
                } else if (arg0.getCanTime() == arg1.getCanTime()) {

                    return 0;
                } else {

                    return -1;
                }
            }
        });
    }

    private void sortTreeMapCanUnitBeanByCanTime() {

        TreeMap<String, CanUnitBean> treeMap = new TreeMap<String, CanUnitBean>(new Comparator<String>() {

            public int compare(String o1, String o2) {

                return o2.compareTo(o1);
            }
        });
        
        treeMap.put("2", new CanUnitBean());
        treeMap.put("b", new CanUnitBean());
        treeMap.put("1", new CanUnitBean());
        treeMap.put("a", new CanUnitBean());
        
        System.out.println("treeMap=" + treeMap);
    }

}