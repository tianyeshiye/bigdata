package function2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.spark.api.java.function.PairFlatMapFunction;

import scala.Tuple2;

public class SortWithinTeregramWithinPartitionsWithGps implements
        PairFlatMapFunction<Iterator<Tuple2<TelegramHash, CanUnitBean>>, TelegramHash, List<List<CanUnitBean>>> {

    private static final long serialVersionUID = -2022345678L;

    private final int timeInterval;

    public SortWithinTeregramWithinPartitionsWithGps(int timeInterval) {

        this.timeInterval = timeInterval;
    }

    public Iterator<Tuple2<TelegramHash, List<List<CanUnitBean>>>> call(
            final Iterator<Tuple2<TelegramHash, CanUnitBean>> tuples) throws Exception {

        return new Iterator<Tuple2<TelegramHash, List<List<CanUnitBean>>>>() {

            boolean repeatedHandlerFlg = true;

            boolean gpsFlg = true;

            private TelegramHash progress = null;

            private Tuple2<TelegramHash, CanUnitBean> aheadTuple = null;

            private TreeMap<Long, List<CanUnitBean>> canUnitBeanTreeMap;

            private void ensureNexrElement() {

                if (progress != null || canUnitBeanTreeMap != null) {
                    return;
                }

                this.canUnitBeanTreeMap = new TreeMap<Long, List<CanUnitBean>>();

                if (aheadTuple != null) {

                    this.progress = aheadTuple._1;
                    addTocanUnitBeanHashMap(canUnitBeanTreeMap, aheadTuple);
                    this.aheadTuple = null;
                }

                while (tuples.hasNext()) {

                    final Tuple2<TelegramHash, CanUnitBean> tuple = tuples.next();

                    if (progress == null || progress.equals(tuple._1)) {

                        this.progress = tuple._1;

                        addTocanUnitBeanHashMap(canUnitBeanTreeMap, tuple);

                    } else {

                        this.aheadTuple = tuple;
                        break;
                    }
                }
            }

            @Override
            public boolean hasNext() {

                ensureNexrElement();

                return canUnitBeanTreeMap != null && !canUnitBeanTreeMap.isEmpty();
            }

            @Override
            public Tuple2<TelegramHash, List<List<CanUnitBean>>> next() {

                if (!hasNext()) {

                    return null;
                }

                Tuple2<TelegramHash, List<List<CanUnitBean>>> next = new Tuple2<TelegramHash, List<List<CanUnitBean>>>(
                        progress, new ArrayList<>(canUnitBeanTreeMap.values()));

                this.progress = null;
                this.canUnitBeanTreeMap = null;
                return next;
            }

            private void addTocanUnitBeanHashMap(Map<Long, List<CanUnitBean>> canUnitBeanHashMap,
                    Tuple2<TelegramHash, CanUnitBean> tuple) {

                CanUnitBean canUnitBean = tuple._2;

                // ******** important
                long canTimeIntervalKey = getCanTimeIntervalKey(canUnitBean, timeInterval);

                canUnitBean.setCanTimeInterval(canTimeIntervalKey);
                // ******** important

                // Gps function
                if (gpsFlg && isGpsData(canUnitBean)) {

                    canTimeIntervalKey = canTimeIntervalKey - 1;
                }

                List<CanUnitBean> canUnitBeanList;

                if (canUnitBeanHashMap.containsKey(canTimeIntervalKey)) {

                    canUnitBeanList = canUnitBeanHashMap.get(canTimeIntervalKey);

                    //// ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
                    /// repeated Handler is needed
                    if (repeatedHandlerFlg) {

                        repeatedHandler(canUnitBeanList, tuple, canTimeIntervalKey);

                    } else {

                        canUnitBeanList.add(canUnitBean);
                    }

                } else {

                    canUnitBeanList = new ArrayList<CanUnitBean>();

                    //// ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
                    /// repeated Handler is needed
                    if (repeatedHandlerFlg) {

                        repeatedHandler(canUnitBeanList, tuple, canTimeIntervalKey);

                    } else {

                        canUnitBeanList.add(canUnitBean);
                    }

                    canUnitBeanHashMap.put(canTimeIntervalKey, canUnitBeanList);
                }
            }

            ///// ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
            ///// Calculation key by Interval
            private Long getCanTimeIntervalKey(CanUnitBean canUnitBean, int timeInterval) {

                long canTime = canUnitBean.getCanTime();

                long canTime1 = canTime / timeInterval;

                long canTime2 = canTime1 * timeInterval;

                return canTime2;
            }

            ///// ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
            ///// repeated Handler

            // Map<CanUnitBean.canTime, List<CanUnitBean.canId> >
            private Map<Long, List<Short>> repeatedMap = new HashMap<Long, List<Short>>();

            private long timestamp;

            // repeated canUnitBean Handler
            private void repeatedHandler(List<CanUnitBean> canUnitBeanList, Tuple2<TelegramHash, CanUnitBean> tuple,
                    long canTimeIntervalKey) {

                CanUnitBean newCanUnitBean = tuple._2;

                if (this.progress.timestamp != this.timestamp) {

                    repeatedMap = new HashMap<Long, List<Short>>();

                    this.timestamp = this.progress.timestamp;
                }

                List<Short> canIdlist = new ArrayList<Short>();

                if (repeatedMap.containsKey(canTimeIntervalKey)) {

                    canIdlist = repeatedMap.get(canTimeIntervalKey);

                    int index = canIdlist.indexOf(newCanUnitBean.getCanId());

                    if (index != -1) {

                        // replace properties
                        replaceCanUnitBeanContent(canUnitBeanList.get(index), newCanUnitBean);

                        // no replace properties
                        // canUnitBeanList.set(index, newCanUnitBean);
                    } else {

                        canUnitBeanList.add(newCanUnitBean);

                        canIdlist.add(newCanUnitBean.getCanId());
                    }
                } else {

                    canUnitBeanList.add(newCanUnitBean);

                    canIdlist.add(newCanUnitBean.getCanId());

                    repeatedMap.put(canTimeIntervalKey, canIdlist);
                }
            }

        };
    }

    // is Gps
    private boolean isGpsData(CanUnitBean canUnitBean) {

        if (canUnitBean.getCanId() == 0x00) {

            return true;
        } else {

            return false;
        }
    }

    // replace canUnitBean content
    private void replaceCanUnitBeanContent(CanUnitBean targetCanUnitBean, CanUnitBean sourceCanUnitBean) {

        Map<String, Object> targetCanUnitBeanDataMap = (Map<String, Object>) targetCanUnitBean.getConvertedDataMap();

        Map<String, Object> sourceCanUnitBeanDataMap = (Map<String, Object>) sourceCanUnitBean.getConvertedDataMap();

        targetCanUnitBeanDataMap.forEach((key, value) -> {

            if (sourceCanUnitBeanDataMap.get(key) != null) {

                targetCanUnitBeanDataMap.replace(key, sourceCanUnitBeanDataMap.get(key));
            }
        });
    }
}