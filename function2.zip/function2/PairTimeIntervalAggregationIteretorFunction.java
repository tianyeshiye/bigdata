package function2;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import scala.Tuple2;

public class PairTimeIntervalAggregationIteretorFunction {

	private final int timeInterval;
	public PairTimeIntervalAggregationIteretorFunction (int timeInterval) {
		this.timeInterval = timeInterval;
	}

	public Iterator<Tuple2<TelegramHash, List<CanUnitBean>>> call(
			final Iterator<Tuple2<TelegramHash, CanUnitBean>> tuples) throws Exception {

        return new Iterator<Tuple2<TelegramHash, List<CanUnitBean>>>() {

        	private TelegramHash progress = null;
        	private CanUnitBean canUnitBean = null;
        	private List<CanUnitBean> message = null;
        	private Tuple2<TelegramHash, CanUnitBean> aheadTuple = null;

        	private void ensureNexrElement() {
        		if (progress !=null || message != null) {
        			return;
        		}

        		this.message = new ArrayList<>();
        		TreeMap<Short, CanUnitBean> rvTelegram = new TreeMap<Short, CanUnitBean>();
        		if (aheadTuple != null) {
        			this.progress = aheadTuple._1;
        			this.canUnitBean = aheadTuple._2;
        			//this.message.add(aheadTuple._2);
        			this.aheadTuple = null;
        			rvTelegram.put(this.canUnitBean.getCanId(), this.canUnitBean);
        		}

        		while (tuples.hasNext()) {
        			final Tuple2<TelegramHash, CanUnitBean> tuple = tuples.next();

        			if (progress == null || (progress.equals(tuple._1) &&
        					canUnitBean.compareToTimeInterval(tuple._2, timeInterval))) {
        				Short catId = tuple._2.getCanId();
        				CanUnitBean rvCanUnitBean = rvTelegram.get(catId);
        				if(rvCanUnitBean == null) {
        					rvCanUnitBean = tuple._2;
        					rvTelegram.put(catId, rvCanUnitBean);
        				}else{//百毫秒未改变
        					//处理假定 某个VIN/CanId标识的所有报文的Label数目相同
        					Map<String ,Object> rvMap = (Map<String,Object>)rvCanUnitBean.getConvertedDataMap();
        					for (Map.Entry<String, Object> entry  : rvMap.entrySet()) {

        						//当前时戳下值为空，pass
        						Object refreshValue = tuple._2.getConvertedDataMap().get(entry.getKey());
        						if(refreshValue == null)
        							continue;

        						rvMap.replace(entry.getKey(),refreshValue);
        					}
        				}
        				this.progress = tuple._1;
        				this.canUnitBean = tuple._2;
        			} else {
        				this.aheadTuple = tuple;
        				break;
        			}
        		}
        		System.out.println("rvTelegram:" + rvTelegram.size());
        		Iterator<Short> it = rvTelegram.keySet().iterator();
        		while(it.hasNext()) {
        			short key = it.next();
        			this.message.add(rvTelegram.get(key));

        		}
        	}
        	@Override
        	public boolean hasNext() {
        		ensureNexrElement();
        		return message != null && !message.isEmpty();
        	}
        	@Override
        	public Tuple2<TelegramHash, List<CanUnitBean>> next() {
        		if (!hasNext()) {
        			//throw new Exception();
        		}
        		Tuple2<TelegramHash, List<CanUnitBean>> next = new Tuple2<TelegramHash, List<CanUnitBean>>(progress,message);
    			this.progress = null;
    			this.message= null;
    			this.canUnitBean= null;
        		return next;
        	}
        };
	}


}
